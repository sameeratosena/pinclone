chrome.runtime.onInstalled.addListener(() => {
    console.log("Image Pin Extension Installed");
});